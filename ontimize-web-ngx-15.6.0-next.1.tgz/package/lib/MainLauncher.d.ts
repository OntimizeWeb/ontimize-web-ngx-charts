import { NgModuleRef } from '@angular/core';
export declare function ontimizePostBootstrap(ngModuleRef: NgModuleRef<any>): NgModuleRef<any>;
//# sourceMappingURL=MainLauncher.d.ts.map