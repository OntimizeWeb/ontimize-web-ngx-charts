import * as i0 from "@angular/core";
import * as i1 from "./o-app-header.component";
import * as i2 from "@angular/common";
import * as i3 from "../language-selector/o-language-selector.module";
import * as i4 from "../user-info/o-user-info.module";
import * as i5 from "../../shared/shared.module";
export declare class OAppHeaderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OAppHeaderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OAppHeaderModule, [typeof i1.OAppHeaderComponent], [typeof i2.CommonModule, typeof i3.OLanguageSelectorModule, typeof i4.OUserInfoModule, typeof i5.OSharedModule], [typeof i1.OAppHeaderComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OAppHeaderModule>;
}
//# sourceMappingURL=o-app-header.module.d.ts.map