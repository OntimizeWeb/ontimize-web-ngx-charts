import { ElementRef, Injector } from '@angular/core';
import { OBaseMenuItemClass } from '../o-base-menu-item.class';
import { OBarMenuBase } from '../o-bar-menu-base.class';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_LOCALE_BAR_MENU_ITEM: string[];
export declare class OLocaleBarMenuItemComponent extends OBaseMenuItemClass {
    protected menu: OBarMenuBase;
    protected elRef: ElementRef;
    protected injector: Injector;
    locale: string;
    constructor(menu: OBarMenuBase, elRef: ElementRef, injector: Injector);
    configureI18n(): void;
    isConfiguredLang(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<OLocaleBarMenuItemComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OLocaleBarMenuItemComponent, "o-locale-bar-menu-item", never, { "locale": "locale"; }, {}, never, never, false, never>;
}
//# sourceMappingURL=o-locale-bar-menu-item.component.d.ts.map