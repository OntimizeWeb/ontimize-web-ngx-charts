import * as i0 from "@angular/core";
export declare class OBarMenuSeparatorComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<OBarMenuSeparatorComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OBarMenuSeparatorComponent, "o-bar-menu-separator", never, {}, {}, never, never, false, never>;
}
//# sourceMappingURL=o-bar-menu-separator.component.d.ts.map