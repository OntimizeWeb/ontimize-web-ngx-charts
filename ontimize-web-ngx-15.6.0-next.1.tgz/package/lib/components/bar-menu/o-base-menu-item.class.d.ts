import { ElementRef, Injector, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { OTranslateService } from '../../services/translate/o-translate.service';
import { OPermissions } from '../../types/o-permissions.type';
import { OBarMenuBase } from './o-bar-menu-base.class';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_BASE_MENU_ITEM: string[];
export declare class OBaseMenuItemClass implements OnInit, OnDestroy {
    protected menu: OBarMenuBase;
    protected elRef: ElementRef;
    protected injector: Injector;
    protected translateService: OTranslateService;
    protected onLanguageChangeSubscription: Subscription;
    protected permissions: OPermissions;
    protected mutationObserver: MutationObserver;
    title: string;
    tooltip: string;
    icon: string;
    restricted: boolean;
    disabled: boolean;
    protected _isHovered: boolean;
    attr: string;
    onMouseover: () => boolean;
    onMouseout: () => boolean;
    constructor(menu: OBarMenuBase, elRef: ElementRef, injector: Injector);
    ngOnInit(): void;
    ngOnDestroy(): void;
    setDOMTitle(): void;
    protected parsePermissions(): void;
    get isHovered(): boolean;
    set isHovered(val: boolean);
    static ɵfac: i0.ɵɵFactoryDeclaration<OBaseMenuItemClass, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<OBaseMenuItemClass, never, never, { "title": "title"; "tooltip": "tooltip"; "icon": "icon"; "attr": "attr"; }, {}, never, never, false, never>;
}
//# sourceMappingURL=o-base-menu-item.class.d.ts.map