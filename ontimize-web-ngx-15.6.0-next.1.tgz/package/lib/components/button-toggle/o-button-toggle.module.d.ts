import * as i0 from "@angular/core";
import * as i1 from "./o-button-toggle.component";
import * as i2 from "./o-button-toggle-group/o-button-toggle-group.component";
import * as i3 from "@angular/common";
import * as i4 from "../../shared/shared.module";
export declare class OButtonToggleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OButtonToggleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OButtonToggleModule, [typeof i1.OButtonToggleComponent, typeof i2.OButtonToggleGroupComponent], [typeof i3.CommonModule, typeof i4.OSharedModule], [typeof i1.OButtonToggleComponent, typeof i2.OButtonToggleGroupComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OButtonToggleModule>;
}
//# sourceMappingURL=o-button-toggle.module.d.ts.map