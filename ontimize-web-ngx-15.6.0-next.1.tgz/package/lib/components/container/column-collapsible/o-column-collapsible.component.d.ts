import { ElementRef, Injector } from '@angular/core';
import { OContainerCollapsibleComponent } from '../o-container-collapsible-component.class';
import * as i0 from "@angular/core";
export declare class OColumnCollapsibleComponent extends OContainerCollapsibleComponent {
    protected elRef: ElementRef;
    protected injector: Injector;
    protected matFormDefaultOption: any;
    constructor(elRef: ElementRef, injector: Injector, matFormDefaultOption: any);
    static ɵfac: i0.ɵɵFactoryDeclaration<OColumnCollapsibleComponent, [null, null, { optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OColumnCollapsibleComponent, "o-column-collapsible", never, {}, {}, never, ["*"], false, never>;
}
//# sourceMappingURL=o-column-collapsible.component.d.ts.map