import * as i0 from "@angular/core";
import * as i1 from "./o-column-collapsible.component";
import * as i2 from "@angular/common";
import * as i3 from "../../../shared/shared.module";
export declare class OColumnCollapsibleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OColumnCollapsibleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OColumnCollapsibleModule, [typeof i1.OColumnCollapsibleComponent], [typeof i2.CommonModule, typeof i3.OSharedModule], [typeof i1.OColumnCollapsibleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OColumnCollapsibleModule>;
}
//# sourceMappingURL=o-column-collapsible.module.d.ts.map