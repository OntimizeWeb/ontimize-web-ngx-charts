import * as i0 from "@angular/core";
import * as i1 from "./o-row-collapsible.component";
import * as i2 from "@angular/common";
import * as i3 from "../../../shared/shared.module";
export declare class ORowCollapsibleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ORowCollapsibleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ORowCollapsibleModule, [typeof i1.ORowCollapsibleComponent], [typeof i2.CommonModule, typeof i3.OSharedModule], [typeof i1.ORowCollapsibleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ORowCollapsibleModule>;
}
//# sourceMappingURL=o-row-collapsible.module.d.ts.map