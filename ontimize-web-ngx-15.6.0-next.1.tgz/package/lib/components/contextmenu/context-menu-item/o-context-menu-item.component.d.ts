import { EventEmitter } from '@angular/core';
import { OnExecuteTableContextEvent } from '../../../interfaces/o-table-context-onexecute.interface';
import { OComponentMenuBaseItem } from '../o-content-menu-base-item.class';
import * as i0 from "@angular/core";
export declare const DEFAULT_CONTEXT_MENU_ITEM_OUTPUTS: string[];
export declare class OContextMenuItemComponent extends OComponentMenuBaseItem {
    execute: EventEmitter<OnExecuteTableContextEvent>;
    type: string;
    onClick(event: MouseEvent): void;
    triggerExecute(data: any, $event?: Event): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OContextMenuItemComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OContextMenuItemComponent, "o-context-menu-item", never, {}, { "execute": "execute"; }, never, never, false, never>;
}
//# sourceMappingURL=o-context-menu-item.component.d.ts.map