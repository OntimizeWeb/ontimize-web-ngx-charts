import { OverlayRef } from '@angular/cdk/overlay';
import { AfterViewInit, EventEmitter, Injector, OnInit, QueryList } from '@angular/core';
import { MatMenuTrigger } from '@angular/material/menu';
import { OContextMenuItemComponent } from '../context-menu-item/o-context-menu-item.component';
import { OComponentMenuBaseItem } from '../o-content-menu-base-item.class';
import * as i0 from "@angular/core";
export declare const DEFAULT_CONTEXT_MENU_CONTENT_INPUTS: string[];
export declare const DEFAULT_CONTEXT_MENU_CONTENT_OUTPUTS: string[];
export declare class OContextMenuContentComponent implements AfterViewInit, OnInit {
    protected injector: Injector;
    menuItems: QueryList<OComponentMenuBaseItem>;
    externalMenuItems: QueryList<OComponentMenuBaseItem>;
    overlay: OverlayRef;
    data: any;
    menuClass: string;
    execute: EventEmitter<{
        event: Event;
        data: any;
        menuItem: OContextMenuItemComponent;
    }>;
    close: EventEmitter<any>;
    trigger: MatMenuTrigger;
    allMenuItems: OComponentMenuBaseItem[];
    constructor(injector: Injector);
    click(): void;
    ngOnInit(): void;
    ngAfterViewInit(): void;
    initialize(): void;
    setData(items: OComponentMenuBaseItem[]): void;
    onMenuClosed(): void;
    closeContent(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OContextMenuContentComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OContextMenuContentComponent, "o-context-menu-content", never, { "menuItems": "menuItems"; "externalMenuItems": "externalMenuItems"; "overlay": "overlay"; "data": "data"; "menuClass": "menuClass"; }, { "execute": "execute"; "close": "close"; }, never, never, false, never>;
}
//# sourceMappingURL=o-context-menu-content.component.d.ts.map