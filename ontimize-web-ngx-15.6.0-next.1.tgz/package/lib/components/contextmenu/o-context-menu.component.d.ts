import { EventEmitter, Injector, OnDestroy, OnInit, QueryList } from '@angular/core';
import { Subscription } from 'rxjs';
import { IOContextMenuContext } from '../../interfaces/o-context-menu.interface';
import { OComponentMenuBaseItem } from './o-content-menu-base-item.class';
import { OContextMenuService } from './o-context-menu.service';
import * as i0 from "@angular/core";
export declare const DEFAULT_OUTPUTS_O_CONTEXT_MENU: string[];
export declare class OContextMenuComponent implements OnDestroy, OnInit {
    protected injector: Injector;
    externalContextMenuItems: QueryList<OComponentMenuBaseItem>;
    oContextMenuItems: QueryList<OComponentMenuBaseItem>;
    origin: HTMLElement;
    onShow: EventEmitter<any>;
    onClose: EventEmitter<any>;
    oContextMenuService: OContextMenuService;
    protected subscription: Subscription;
    constructor(injector: Injector);
    ngOnInit(): void;
    ngOnDestroy(): void;
    showContextMenu(params: IOContextMenuContext): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OContextMenuComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OContextMenuComponent, "o-context-menu", never, {}, { "onShow": "onShow"; "onClose": "onClose"; }, ["oContextMenuItems"], never, false, never>;
}
//# sourceMappingURL=o-context-menu.component.d.ts.map