import * as i0 from "@angular/core";
import * as i1 from "./o-context-menu.directive";
import * as i2 from "./context-menu/o-context-menu-content.component";
import * as i3 from "./o-context-menu.component";
import * as i4 from "./context-menu-item/o-context-menu-item.component";
import * as i5 from "./context-menu-group/o-context-menu-group.component";
import * as i6 from "./context-menu/o-wrapper-content-menu/o-wrapper-content-menu.component";
import * as i7 from "./context-menu-separator/o-context-menu-separator.component";
import * as i8 from "@angular/common";
import * as i9 from "../../shared/shared.module";
export declare class OContextMenuModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OContextMenuModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OContextMenuModule, [typeof i1.OContextMenuDirective, typeof i2.OContextMenuContentComponent, typeof i3.OContextMenuComponent, typeof i4.OContextMenuItemComponent, typeof i5.OContextMenuGroupComponent, typeof i6.OWrapperContentMenuComponent, typeof i7.OContextMenuSeparatorComponent], [typeof i8.CommonModule, typeof i9.OSharedModule], [typeof i8.CommonModule, typeof i1.OContextMenuDirective, typeof i3.OContextMenuComponent, typeof i4.OContextMenuItemComponent, typeof i5.OContextMenuGroupComponent, typeof i7.OContextMenuSeparatorComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OContextMenuModule>;
}
//# sourceMappingURL=o-context-menu.module.d.ts.map