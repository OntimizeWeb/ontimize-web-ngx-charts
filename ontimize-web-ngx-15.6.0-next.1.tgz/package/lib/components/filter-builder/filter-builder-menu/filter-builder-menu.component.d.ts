import { Injector } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { DialogService } from '../../../services/dialog.service';
import { OFilterBuilderComponent } from '../o-filter-builder.component';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_FILTER_BUILDER_MENU: string[];
export declare class OFilterBuilderMenuComponent {
    protected injector: Injector;
    protected dialog: MatDialog;
    protected dialogService: DialogService;
    protected _filterBuilder: OFilterBuilderComponent;
    showFilterOption: boolean;
    showClearFilterOption: boolean;
    icon: string;
    svgIcon: string;
    defaultSvgIcon: string;
    constructor(injector: Injector);
    onStoreFilterClicked(): void;
    onLoadFilterClicked(): void;
    onClearFilterClicked(): void;
    onFilterClicked(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OFilterBuilderMenuComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OFilterBuilderMenuComponent, "o-filter-builder-menu", never, { "_filterBuilder": "oFilterBuilder"; "icon": "icon"; "svgIcon": "svg-icon"; "showClearFilterOption": "show-clear-filter-option"; "showFilterOption": "show-filter-option"; }, {}, never, never, false, never>;
}
//# sourceMappingURL=filter-builder-menu.component.d.ts.map