import type { OFilterBuilderValues } from "../../types/o-filter-builder-values.type";
export declare abstract class OFilterBuilderBase {
    abstract getFilterValues(): OFilterBuilderValues[];
    abstract getDataToStore(): any;
    abstract getComponentKey(): string;
}
//# sourceMappingURL=o-filter-builder-base.class.d.ts.map