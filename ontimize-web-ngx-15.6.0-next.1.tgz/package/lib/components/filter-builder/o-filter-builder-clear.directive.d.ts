import { OFilterBuilderComponent } from './o-filter-builder.component';
import * as i0 from "@angular/core";
export declare class OFilterBuilderClearDirective {
    protected _filterBuilder: OFilterBuilderComponent;
    constructor(filterBuilder: OFilterBuilderComponent);
    onClick(e?: Event): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OFilterBuilderClearDirective, [{ optional: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<OFilterBuilderClearDirective, "[oFilterBuilderClear]", ["oFilterBuilderClear"], { "_filterBuilder": "oFilterBuilderClear"; }, {}, never, never, false, never>;
}
//# sourceMappingURL=o-filter-builder-clear.directive.d.ts.map