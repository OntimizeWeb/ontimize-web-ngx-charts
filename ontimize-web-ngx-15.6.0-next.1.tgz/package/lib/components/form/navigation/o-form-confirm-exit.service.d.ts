import { DialogService } from '../../../services/dialog.service';
import { OFormBase } from '../o-form-base.class';
import * as i0 from "@angular/core";
export declare class OFormConfirmExitService {
    protected dialogService: DialogService;
    protected confirmDialogSubscription: Promise<boolean>;
    constructor(dialogService: DialogService);
    subscribeToDiscardChanges(form: OFormBase, ignoreAttrs?: string[]): Promise<boolean>;
    protected restart(): void;
    protected getConfirmDialogSubscription(form: OFormBase): Promise<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OFormConfirmExitService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OFormConfirmExitService>;
}
//# sourceMappingURL=o-form-confirm-exit.service.d.ts.map