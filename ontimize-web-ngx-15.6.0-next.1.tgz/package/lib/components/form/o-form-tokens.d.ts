import { InjectionToken } from "@angular/core";
import { OFormGlobalConfig } from "../../types/form/o-form-global-config.type";
export declare const O_FORM_GLOBAL_CONFIG: InjectionToken<OFormGlobalConfig>;
//# sourceMappingURL=o-form-tokens.d.ts.map