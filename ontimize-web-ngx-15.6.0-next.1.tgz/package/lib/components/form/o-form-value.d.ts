export declare class OFormValue {
    value: any;
    constructor(value?: any);
}
//# sourceMappingURL=o-form-value.d.ts.map