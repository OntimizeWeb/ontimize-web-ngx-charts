export declare abstract class OFormToolbarBase {
    isDetail: boolean;
    editMode: boolean;
    abstract setInitialMode(): void;
    abstract setInsertMode(): void;
    abstract setEditMode(): void;
}
//# sourceMappingURL=o-form-toolbar-base.class.d.ts.map