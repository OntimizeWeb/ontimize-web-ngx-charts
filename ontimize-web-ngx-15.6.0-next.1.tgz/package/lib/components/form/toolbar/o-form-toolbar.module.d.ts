import * as i0 from "@angular/core";
import * as i1 from "../navigation/o-form-navigation.component";
import * as i2 from "./o-form-toolbar.component";
import * as i3 from "@angular/common";
import * as i4 from "../../../shared/shared.module";
export declare class OFormToolbarModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OFormToolbarModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OFormToolbarModule, [typeof i1.OFormNavigationComponent, typeof i2.OFormToolbarComponent], [typeof i3.CommonModule, typeof i4.OSharedModule], [typeof i1.OFormNavigationComponent, typeof i2.OFormToolbarComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OFormToolbarModule>;
}
//# sourceMappingURL=o-form-toolbar.module.d.ts.map