import { Injector, OnInit, TemplateRef } from '@angular/core';
import { ICurrencyPipeArgument, OCurrencyPipe } from '../../../../../pipes/o-currency.pipe';
import { CurrencyService } from '../../../../../services/currency.service';
import { OComboRendererRealComponent } from '../real/o-combo-renderer-real.component';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_COMBO_RENDERER_CURRENCY: string[];
export declare class OComboRendererCurrencyComponent extends OComboRendererRealComponent implements OnInit {
    protected injector: Injector;
    minDecimalDigits: number;
    maxDecimalDigits: number;
    protected currencySymbol: string;
    protected currencySymbolPosition: string;
    protected decimalSeparator: string;
    protected grouping: boolean;
    protected thousandSeparator: string;
    protected currencyService: CurrencyService;
    protected componentPipe: OCurrencyPipe;
    protected pipeArguments: ICurrencyPipeArgument;
    templateref: TemplateRef<any>;
    constructor(injector: Injector);
    setComponentPipe(): void;
    initialize(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OComboRendererCurrencyComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OComboRendererCurrencyComponent, "o-combo-renderer-currency", never, { "currencySymbol": "currency-symbol"; "currencySymbolPosition": "currency-symbol-position"; }, {}, never, never, false, never>;
}
//# sourceMappingURL=o-combo-renderer-currency.component.d.ts.map