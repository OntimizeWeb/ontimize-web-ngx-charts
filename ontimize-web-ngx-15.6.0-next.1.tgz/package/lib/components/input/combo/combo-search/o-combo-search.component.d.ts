import { ChangeDetectorRef, ElementRef, EventEmitter, OnDestroy, OnInit, QueryList } from '@angular/core';
import { MatOption } from '@angular/material/core';
import { MatSelect } from '@angular/material/select';
import { Subject } from 'rxjs';
import * as i0 from "@angular/core";
export declare class OComboSearchComponent implements OnInit, OnDestroy {
    matSelect: MatSelect;
    private changeDetectorRef;
    placeholder: string;
    _options: QueryList<MatOption>;
    get value(): string;
    protected _value: string;
    protected previousSelectedValues: any[];
    protected searchSelectInput: ElementRef;
    protected change: EventEmitter<string>;
    protected _onDestroy: Subject<void>;
    constructor(matSelect: MatSelect, changeDetectorRef: ChangeDetectorRef);
    ngOnInit(): void;
    ngOnDestroy(): void;
    onChange: Function;
    onTouched: Function;
    handleKeydown(event: KeyboardEvent): void;
    onInputChange(value: any): void;
    onBlur(value: string): void;
    writeValue(value: string): void;
    registerOnChange(fn: Function): void;
    registerOnTouched(fn: Function): void;
    focus(): void;
    reset(focus?: boolean): void;
    protected initMultipleHandling(): void;
    resetSelectedValues(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OComboSearchComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OComboSearchComponent, "o-combo-search", never, {}, {}, never, never, false, never>;
}
//# sourceMappingURL=o-combo-search.component.d.ts.map