import * as i0 from "@angular/core";
import * as i1 from "./o-combo.component";
import * as i2 from "./combo-search/o-combo-search.component";
import * as i3 from "./combo-renderer/boolean/o-combo-renderer-boolean.component";
import * as i4 from "./combo-renderer/integer/o-combo-renderer-integer.component";
import * as i5 from "./combo-renderer/real/o-combo-renderer-real.component";
import * as i6 from "./combo-renderer/currency/o-combo-renderer-currency.component";
import * as i7 from "./combo-renderer/date/o-combo-renderer-date.component";
import * as i8 from "./combo-renderer/percentage/o-combo-renderer-percentage.component";
import * as i9 from "./combo-renderer/icon/o-combo-renderer-icon.component";
import * as i10 from "@angular/common";
import * as i11 from "../../../shared/shared.module";
import * as i12 from "../../contextmenu/o-context-menu.module";
export declare class OComboModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OComboModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OComboModule, [typeof i1.OComboComponent, typeof i2.OComboSearchComponent, typeof i3.OComboRendererBooleanComponent, typeof i4.OComboRendererIntegerComponent, typeof i5.OComboRendererRealComponent, typeof i6.OComboRendererCurrencyComponent, typeof i7.OComboRendererDateComponent, typeof i8.OComboRendererPercentageComponent, typeof i9.OComboRendererIconComponent], [typeof i10.CommonModule, typeof i11.OSharedModule, typeof i12.OContextMenuModule], [typeof i1.OComboComponent, typeof i2.OComboSearchComponent, typeof i3.OComboRendererBooleanComponent, typeof i4.OComboRendererIntegerComponent, typeof i5.OComboRendererRealComponent, typeof i6.OComboRendererCurrencyComponent, typeof i7.OComboRendererDateComponent, typeof i8.OComboRendererPercentageComponent, typeof i9.OComboRendererIconComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OComboModule>;
}
//# sourceMappingURL=o-combo.module.d.ts.map