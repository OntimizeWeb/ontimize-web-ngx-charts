import * as i0 from "@angular/core";
import * as i1 from "./o-currency-input.component";
import * as i2 from "@angular/common";
import * as i3 from "../../../shared/shared.module";
import * as i4 from "../real-input/o-real-input.module";
export declare class OCurrencyInputModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OCurrencyInputModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OCurrencyInputModule, [typeof i1.OCurrencyInputComponent], [typeof i2.CommonModule, typeof i3.OSharedModule, typeof i4.ORealInputModule], [typeof i1.OCurrencyInputComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OCurrencyInputModule>;
}
//# sourceMappingURL=o-currency-input.module.d.ts.map