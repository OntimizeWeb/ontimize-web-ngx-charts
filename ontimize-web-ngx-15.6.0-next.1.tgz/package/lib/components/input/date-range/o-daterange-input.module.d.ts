import * as i0 from "@angular/core";
import * as i1 from "./o-daterange-input.component";
import * as i2 from "@angular/common";
import * as i3 from "../../../shared/shared.module";
export declare class ODateRangeInputModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ODateRangeInputModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ODateRangeInputModule, [typeof i1.ODateRangeInputComponent], [typeof i2.CommonModule, typeof i3.OSharedModule], [typeof i1.ODateRangeInputComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ODateRangeInputModule>;
}
//# sourceMappingURL=o-daterange-input.module.d.ts.map