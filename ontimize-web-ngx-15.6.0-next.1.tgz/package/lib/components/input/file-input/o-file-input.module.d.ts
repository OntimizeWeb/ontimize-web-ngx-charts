import * as i0 from "@angular/core";
import * as i1 from "./o-file-input.component";
import * as i2 from "@angular/common";
import * as i3 from "../../../shared/shared.module";
export declare class OFileInputModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OFileInputModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OFileInputModule, [typeof i1.OFileInputComponent], [typeof i2.CommonModule, typeof i3.OSharedModule], [typeof i1.OFileInputComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OFileInputModule>;
}
//# sourceMappingURL=o-file-input.module.d.ts.map