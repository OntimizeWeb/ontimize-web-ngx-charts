import { Injector, OnInit, TemplateRef } from '@angular/core';
import { IMomentPipeArgument, OMomentPipe } from '../../../../../pipes/o-moment.pipe';
import { OListPickerCustomRenderer } from '../o-list-picker-renderer.class';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_LISTPICKER_RENDERER_DATE: any[];
export declare class OListPickerRendererDateComponent extends OListPickerCustomRenderer implements OnInit {
    protected injector: Injector;
    protected componentPipe: OMomentPipe;
    protected pipeArguments: IMomentPipeArgument;
    protected format: string;
    templateref: TemplateRef<any>;
    constructor(injector: Injector);
    setComponentPipe(): void;
    initialize(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OListPickerRendererDateComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OListPickerRendererDateComponent, "o-list-picker-renderer-date", never, { "format": "format"; }, {}, never, never, false, never>;
}
//# sourceMappingURL=o-list-picker-renderer-date.component.d.ts.map