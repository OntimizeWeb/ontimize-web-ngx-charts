import { AfterContentInit, Injector, OnInit, TemplateRef } from '@angular/core';
import { IIntegerPipeArgument, OIntegerPipe } from '../../../../../pipes/o-integer.pipe';
import { OListPickerCustomRenderer } from '../o-list-picker-renderer.class';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_LISTPICKER_RENDERER_INTEGER: any[];
export declare class OListPickerRendererIntegerComponent extends OListPickerCustomRenderer implements AfterContentInit, OnInit {
    protected injector: Injector;
    protected grouping: boolean;
    protected thousandSeparator: string;
    protected componentPipe: OIntegerPipe;
    protected pipeArguments: IIntegerPipeArgument;
    templateref: TemplateRef<any>;
    constructor(injector: Injector);
    setComponentPipe(): void;
    initialize(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OListPickerRendererIntegerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OListPickerRendererIntegerComponent, "o-list-picker-renderer-integer", never, { "grouping": "grouping"; "thousandSeparator": "thousand-separator"; }, {}, never, never, false, never>;
}
//# sourceMappingURL=o-list-picker-renderer-integer.component.d.ts.map