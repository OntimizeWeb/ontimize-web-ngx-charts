import * as i0 from "@angular/core";
import * as i1 from "./o-nif-input.component";
import * as i2 from "../../../shared/shared.module";
import * as i3 from "@angular/common";
import * as i4 from "../text-input/o-text-input.module";
export declare class ONIFInputModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ONIFInputModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ONIFInputModule, [typeof i1.ONIFInputComponent], [typeof i2.OSharedModule, typeof i3.CommonModule, typeof i4.OTextInputModule], [typeof i1.ONIFInputComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ONIFInputModule>;
}
//# sourceMappingURL=o-nif-input.module.d.ts.map