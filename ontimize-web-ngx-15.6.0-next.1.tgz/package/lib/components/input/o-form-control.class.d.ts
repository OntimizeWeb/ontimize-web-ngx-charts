import { AbstractControlOptions, AsyncValidatorFn, UntypedFormControl, ValidatorFn } from '@angular/forms';
import { OFormDataComponent } from '../o-form-data-component.class';
export declare class OFormControl extends UntypedFormControl {
    fControlChildren: (UntypedFormControl | OFormDataComponent)[];
    constructor(formState?: any, validatorOrOpts?: ValidatorFn | ValidatorFn[] | AbstractControlOptions | null, asyncValidator?: AsyncValidatorFn | AsyncValidatorFn[] | null);
    markAsTouched(opts?: {
        onlySelf?: boolean;
    }): void;
    markAsDirty(opts?: {
        onlySelf?: boolean;
    }): void;
    markAsPristine(opts?: {
        onlySelf?: boolean;
    }): void;
    getValue(): any;
}
//# sourceMappingURL=o-form-control.class.d.ts.map