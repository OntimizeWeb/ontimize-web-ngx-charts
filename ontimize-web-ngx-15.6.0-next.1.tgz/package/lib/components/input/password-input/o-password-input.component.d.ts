import { ElementRef, Injector, OnInit } from '@angular/core';
import { OFormComponent } from '../../form/o-form.component';
import { OTextInputComponent } from '../text-input/o-text-input.component';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_PASSWORD_INPUT: string[];
export declare class OPasswordInputComponent extends OTextInputComponent implements OnInit {
    hide: boolean;
    showPasswordButton: boolean;
    constructor(form: OFormComponent, elRef: ElementRef, injector: Injector);
    static ɵfac: i0.ɵɵFactoryDeclaration<OPasswordInputComponent, [{ optional: true; }, null, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OPasswordInputComponent, "o-password-input", never, { "showPasswordButton": "show-password-button"; }, {}, never, never, false, never>;
}
//# sourceMappingURL=o-password-input.component.d.ts.map