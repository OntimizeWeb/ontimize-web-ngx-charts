import { OnInit } from '@angular/core';
import { IPercentPipeArgument, OPercentageValueBaseType, OPercentPipe } from '../../../pipes/o-percentage.pipe';
import { ORealInputComponent } from '../real-input/o-real-input.component';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_PERCENT_INPUT: string[];
export declare const DEFAULT_OUTPUTS_O_PERCENT_INPUT: any[];
export declare class OPercentInputComponent extends ORealInputComponent implements OnInit {
    grouping: boolean;
    valueBase: OPercentageValueBaseType;
    protected componentPipe: OPercentPipe;
    protected pipeArguments: IPercentPipeArgument;
    ngOnInit(): void;
    setComponentPipe(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OPercentInputComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OPercentInputComponent, "o-percent-input", never, { "valueBase": "value-base"; }, {}, never, never, false, never>;
}
//# sourceMappingURL=o-percent-input.component.d.ts.map