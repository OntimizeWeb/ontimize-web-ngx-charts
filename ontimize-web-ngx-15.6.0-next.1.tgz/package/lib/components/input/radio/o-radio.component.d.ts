import { AfterViewInit, ElementRef, Injector, OnDestroy } from '@angular/core';
import { MatRadioChange, MatRadioGroup } from '@angular/material/radio';
import { OFormValue } from '../../form/o-form-value';
import { OFormComponent } from '../../form/o-form.component';
import { OFormServiceComponent } from '../o-form-service-component.class';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_RADIO: string[];
export declare class ORadioComponent extends OFormServiceComponent implements AfterViewInit, OnDestroy {
    layout: 'row' | 'column';
    labelPosition: 'before' | 'after';
    labelGap: string;
    value: OFormValue;
    tabsSubscriptions: any;
    mrg: MatRadioGroup;
    formLayoutManagerTabIndex: number;
    constructor(form: OFormComponent, elRef: ElementRef, injector: Injector);
    ngAfterViewInit(): void;
    updateFormLayoutManagerState(): void;
    onMatRadioGroupChange(e: MatRadioChange): void;
    getValueColumn(item: any): any;
    getDescriptionValue(): string;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ORadioComponent, [{ optional: true; }, null, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ORadioComponent, "o-radio", never, { "layout": "layout"; "labelPosition": "label-position"; "labelGap": "label-gap"; }, {}, never, never, false, never>;
}
//# sourceMappingURL=o-radio.component.d.ts.map