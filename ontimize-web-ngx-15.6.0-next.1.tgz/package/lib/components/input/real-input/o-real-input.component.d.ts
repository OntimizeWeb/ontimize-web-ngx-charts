import { ElementRef, Injector, OnInit } from '@angular/core';
import { UntypedFormControl, ValidationErrors, ValidatorFn } from '@angular/forms';
import { IRealPipeArgument } from '../../../pipes/o-real.pipe';
import { NumberService } from '../../../services/number.service';
import { OFormComponent } from '../../form/o-form.component';
import { OIntegerInputComponent } from '../integer-input/o-integer-input.component';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_REAL_INPUT: string[];
export declare class ORealInputComponent extends OIntegerInputComponent implements OnInit {
    minDecimalDigits: number;
    maxDecimalDigits: number;
    step: number;
    grouping: boolean;
    strict: boolean;
    protected decimalSeparator: string;
    protected pipeArguments: IRealPipeArgument;
    protected numberService: NumberService;
    constructor(form: OFormComponent, elRef: ElementRef, injector: Injector);
    setComponentPipe(): void;
    initialize(): void;
    ngOnInit(): void;
    resolveValidators(): ValidatorFn[];
    ensureOFormValue(arg: any): void;
    protected maxDecimalDigitsValidator(control: UntypedFormControl): ValidationErrors;
    protected initializeStep(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ORealInputComponent, [{ optional: true; }, null, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ORealInputComponent, "o-real-input", never, { "minDecimalDigits": "min-decimal-digits"; "maxDecimalDigits": "max-decimal-digits"; "decimalSeparator": "decimal-separator"; "strict": "strict"; }, {}, never, never, false, never>;
}
//# sourceMappingURL=o-real-input.component.d.ts.map