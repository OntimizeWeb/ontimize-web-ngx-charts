import { ElementRef, Injector } from '@angular/core';
import { ThemePalette } from '@angular/material/core';
import { OFormComponent } from '../../form/o-form.component';
import { OBooleanFormDataComponent } from '../o-boolean-form-data-component.class';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_SLIDETOGGLE: string[];
export declare class OSlideToggleComponent extends OBooleanFormDataComponent {
    color: ThemePalette;
    labelPosition: 'before' | 'after';
    constructor(form: OFormComponent, elRef: ElementRef, injector: Injector);
    isChecked(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<OSlideToggleComponent, [{ optional: true; }, null, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OSlideToggleComponent, "o-slide-toggle", never, { "trueValue": "true-value"; "falseValue": "false-value"; "booleanType": "boolean-type"; "color": "color"; "labelPosition": "label-position"; }, {}, never, never, false, never>;
}
//# sourceMappingURL=o-slide-toggle.component.d.ts.map