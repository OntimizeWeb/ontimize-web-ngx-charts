import * as i0 from "@angular/core";
import * as i1 from "./o-list.component";
import * as i2 from "./list-item/o-list-item.component";
import * as i3 from "./renderers/avatar/o-list-item-avatar.component";
import * as i4 from "./renderers/card-image/o-list-item-card-image.component";
import * as i5 from "./renderers/card/o-list-item-card.component";
import * as i6 from "./renderers/text/o-list-item-text.component";
import * as i7 from "./skeleton/o-list-skeleton.component";
import * as i8 from "@angular/common";
import * as i9 from "../input/search-input/o-search-input.module";
import * as i10 from "../../shared/shared.module";
import * as i11 from "@angular/router";
import * as i12 from "../o-data-toolbar/o-data-toolbar.module";
import * as i13 from "ngx-skeleton-loader";
export declare class OListModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OListModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OListModule, [typeof i1.OListComponent, typeof i2.OListItemComponent, typeof i3.OListItemAvatarComponent, typeof i4.OListItemCardImageComponent, typeof i5.OListItemCardComponent, typeof i6.OListItemTextComponent, typeof i7.OListSkeletonComponent], [typeof i8.CommonModule, typeof i9.OSearchInputModule, typeof i10.OSharedModule, typeof i11.RouterModule, typeof i12.ODataToolbarModule, typeof i13.NgxSkeletonLoaderModule], [typeof i1.OListComponent, typeof i2.OListItemComponent, typeof i3.OListItemAvatarComponent, typeof i4.OListItemCardImageComponent, typeof i5.OListItemCardComponent, typeof i6.OListItemTextComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OListModule>;
}
//# sourceMappingURL=o-list.module.d.ts.map