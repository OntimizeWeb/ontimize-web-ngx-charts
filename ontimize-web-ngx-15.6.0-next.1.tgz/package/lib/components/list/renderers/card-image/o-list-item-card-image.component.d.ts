import { AfterViewInit, ElementRef, EventEmitter, Injector, Renderer2 } from '@angular/core';
import { OListItemComponent } from '../../list-item/o-list-item.component';
import { OListItemCardRenderer } from '../o-list-item-card-renderer.class';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_LIST_ITEM_CARD_IMAGE: string[];
export declare const DEFAULT_OUTPUTS_O_LIST_ITEM_CARD_IMAGE: string[];
export declare class OListItemCardImageComponent extends OListItemCardRenderer implements AfterViewInit {
    protected _content: string;
    protected _avatar: string;
    protected _icon: string;
    protected _collapsible: boolean;
    protected _collapsed: boolean;
    onIconClick: EventEmitter<object>;
    constructor(elRef: ElementRef, _renderer: Renderer2, _injector: Injector, _listItem: OListItemComponent);
    ngAfterViewInit(): void;
    onActionIconClick(e?: Event): void;
    get content(): string;
    set content(val: string);
    get avatar(): string;
    set avatar(val: string);
    get icon(): string;
    set icon(val: string);
    get collapsible(): boolean;
    set collapsible(val: boolean);
    get collapsed(): boolean;
    set collapsed(val: boolean);
    static ɵfac: i0.ɵɵFactoryDeclaration<OListItemCardImageComponent, [null, null, null, { optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OListItemCardImageComponent, "o-list-item-card-image", never, { "content": "content"; "avatar": "avatar"; "icon": "icon"; "collapsible": "collapsible"; "collapsed": "collapsed"; }, { "onIconClick": "icon-action"; }, never, never, false, never>;
}
//# sourceMappingURL=o-list-item-card-image.component.d.ts.map