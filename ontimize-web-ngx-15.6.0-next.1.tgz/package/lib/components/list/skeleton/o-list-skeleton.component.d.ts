import { ElementRef, Injector } from '@angular/core';
import { OSkeletonComponent } from '../../o-skeleton.component';
import * as i0 from "@angular/core";
export declare class OListSkeletonComponent extends OSkeletonComponent {
    protected elRef: ElementRef;
    protected injector: Injector;
    constructor(elRef: ElementRef, injector: Injector);
    get count(): any[];
    static ɵfac: i0.ɵɵFactoryDeclaration<OListSkeletonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OListSkeletonComponent, "o-list-skeleton", never, {}, {}, never, never, false, never>;
}
//# sourceMappingURL=o-list-skeleton.component.d.ts.map