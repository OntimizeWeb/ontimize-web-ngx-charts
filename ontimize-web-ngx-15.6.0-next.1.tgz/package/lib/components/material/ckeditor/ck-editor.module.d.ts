import * as i0 from "@angular/core";
import * as i1 from "./ck-editor.component";
import * as i2 from "@angular/forms";
export declare class CKEditorModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CKEditorModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CKEditorModule, [typeof i1.CKEditorComponent], never, [typeof i2.FormsModule, typeof i1.CKEditorComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CKEditorModule>;
}
//# sourceMappingURL=ck-editor.module.d.ts.map