import { Injector, OnDestroy } from "@angular/core";
import { Subscription } from "rxjs";
import { AppearanceService } from "../services/appearance.service";
import * as i0 from "@angular/core";
export declare class OSkeletonComponent implements OnDestroy {
    protected injector: Injector;
    isDarkMode: boolean;
    subscription: Subscription;
    appearanceService: AppearanceService;
    constructor(injector: Injector);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OSkeletonComponent, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<OSkeletonComponent, never, never, {}, {}, never, never, false, never>;
}
//# sourceMappingURL=o-skeleton.component.d.ts.map