import { Injector } from '@angular/core';
import { OTableColumnCalculated } from '../../../../interfaces/o-table-column-calculated.interface';
import { OperatorFunction } from '../../../../types/operation-function.type';
import { OTableComponent } from '../../o-table.component';
import { OTableColumnComponent } from '../o-table-column.component';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_TABLE_COLUMN_CALCULATED: string[];
export declare class OTableColumnCalculatedComponent extends OTableColumnComponent implements OTableColumnCalculated {
    table: OTableComponent;
    protected injector: Injector;
    operation: string;
    functionOperation: OperatorFunction;
    constructor(table: OTableComponent, injector: Injector);
    static ɵfac: i0.ɵɵFactoryDeclaration<OTableColumnCalculatedComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OTableColumnCalculatedComponent, "o-table-column-calculated", never, { "operation": "operation"; "functionOperation": "operation-function"; }, {}, never, never, false, never>;
}
//# sourceMappingURL=o-table-column-calculated.component.d.ts.map