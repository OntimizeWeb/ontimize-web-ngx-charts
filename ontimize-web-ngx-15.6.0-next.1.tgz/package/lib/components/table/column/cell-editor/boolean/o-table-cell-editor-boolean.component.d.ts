import { Injector, OnInit, TemplateRef } from '@angular/core';
import { MatCheckboxChange } from '@angular/material/checkbox';
import { OBaseTableCellEditor } from '../o-base-table-cell-editor.class';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_TABLE_CELL_EDITOR_BOOLEAN: string[];
export declare class OTableCellEditorBooleanComponent extends OBaseTableCellEditor implements OnInit {
    protected injector: Injector;
    templateref: TemplateRef<any>;
    indeterminate: boolean;
    indeterminateOnNull: boolean;
    trueValue: any;
    falseValue: any;
    protected _booleanType: string;
    autoCommit: boolean;
    constructor(injector: Injector);
    initialize(): void;
    get booleanType(): string;
    set booleanType(arg: string);
    protected parseInputs(): void;
    protected parseStringInputs(): void;
    protected parseNumberInputs(): void;
    startEdition(data: any): void;
    getCellData(): any;
    hasCellDataTrueValue(cellData: any): boolean;
    protected parseValueByType(val: any): string | number | boolean;
    onChange(arg: MatCheckboxChange): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OTableCellEditorBooleanComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OTableCellEditorBooleanComponent, "o-table-cell-editor-boolean", never, { "indeterminateOnNull": "indeterminate-on-null"; "trueValue": "true-value"; "falseValue": "false-value"; "booleanType": "boolean-type"; "autoCommit": "auto-commit"; }, {}, never, never, false, never>;
}
//# sourceMappingURL=o-table-cell-editor-boolean.component.d.ts.map