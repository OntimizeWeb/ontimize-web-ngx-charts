import { Injector, TemplateRef } from '@angular/core';
import { ValidatorFn } from '@angular/forms';
import { OBaseTableCellEditor } from '../o-base-table-cell-editor.class';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_TABLE_CELL_EDITOR_INTEGER: string[];
export declare class OTableCellEditorIntegerComponent extends OBaseTableCellEditor {
    protected injector: Injector;
    templateref: TemplateRef<any>;
    min: number;
    max: number;
    step: number;
    constructor(injector: Injector);
    getCellData(): number;
    resolveValidators(): ValidatorFn[];
    static ɵfac: i0.ɵɵFactoryDeclaration<OTableCellEditorIntegerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OTableCellEditorIntegerComponent, "o-table-cell-editor-integer", never, { "min": "min"; "max": "max"; "step": "step"; }, {}, never, never, false, never>;
}
//# sourceMappingURL=o-table-cell-editor-integer.component.d.ts.map