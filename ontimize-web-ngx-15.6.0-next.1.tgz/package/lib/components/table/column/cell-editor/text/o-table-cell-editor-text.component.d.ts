import { Injector, TemplateRef } from '@angular/core';
import { OBaseTableCellEditor } from '../o-base-table-cell-editor.class';
import * as i0 from "@angular/core";
export declare class OTableCellEditorTextComponent extends OBaseTableCellEditor {
    protected injector: Injector;
    templateref: TemplateRef<any>;
    constructor(injector: Injector);
    static ɵfac: i0.ɵɵFactoryDeclaration<OTableCellEditorTextComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OTableCellEditorTextComponent, "o-table-cell-editor-text", never, {}, {}, never, never, false, never>;
}
//# sourceMappingURL=o-table-cell-editor-text.component.d.ts.map