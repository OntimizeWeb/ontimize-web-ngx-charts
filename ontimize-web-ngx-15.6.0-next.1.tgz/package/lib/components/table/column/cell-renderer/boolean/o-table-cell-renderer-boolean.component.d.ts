import { Injector, OnInit, TemplateRef } from '@angular/core';
import { OTranslateService } from '../../../../../services/translate/o-translate.service';
import { OBaseTableCellRenderer } from '../o-base-table-cell-renderer.class';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_TABLE_CELL_RENDERER_BOOLEAN: string[];
export declare class OTableCellRendererBooleanComponent extends OBaseTableCellRenderer implements OnInit {
    protected injector: Injector;
    trueValue: any;
    falseValue: any;
    protected _renderTrueValue: any;
    protected _renderFalseValue: any;
    protected _renderType: string;
    protected _booleanType: string;
    protected translateService: OTranslateService;
    templateref: TemplateRef<any>;
    constructor(injector: Injector);
    initialize(): void;
    protected parseInputs(): void;
    protected parseStringInputs(): void;
    protected parseNumberInputs(): void;
    hasCellDataTrueValue(cellData: any): boolean;
    getCellData(cellvalue: any, rowvalue?: any): any;
    get booleanType(): string;
    set booleanType(arg: string);
    get renderType(): string;
    set renderType(arg: string);
    get renderTrueValue(): string;
    set renderTrueValue(arg: string);
    get renderFalseValue(): string;
    set renderFalseValue(arg: string);
    static ɵfac: i0.ɵɵFactoryDeclaration<OTableCellRendererBooleanComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OTableCellRendererBooleanComponent, "o-table-cell-renderer-boolean", never, { "trueValue": "true-value"; "falseValue": "false-value"; "booleanType": "boolean-type"; "renderTrueValue": "render-true-value"; "renderFalseValue": "render-false-value"; "renderType": "render-type"; }, {}, never, never, false, never>;
}
//# sourceMappingURL=o-table-cell-renderer-boolean.component.d.ts.map