import { OTableCellRendererActionComponent } from './action/o-table-cell-renderer-action.component';
import { OTableCellRendererBooleanComponent } from './boolean/o-table-cell-renderer-boolean.component';
import { OTableCellRendererCurrencyComponent } from './currency/o-table-cell-renderer-currency.component';
import { OTableCellRendererDateComponent } from './date/o-table-cell-renderer-date.component';
import { OTableCellRendererImageComponent } from './image/o-table-cell-renderer-image.component';
import { OTableCellRendererIntegerComponent } from './integer/o-table-cell-renderer-integer.component';
import { OTableCellRendererPercentageComponent } from './percentage/o-table-cell-renderer-percentage.component';
import { OTableCellRendererRealComponent } from './real/o-table-cell-renderer-real.component';
import { OTableCellRendererServiceComponent } from './service/o-table-cell-renderer-service.component';
import { OTableCellRendererTimeComponent } from './time/o-table-cell-renderer-time.component';
import { OTableCellRendererTranslateComponent } from './translate/o-table-cell-renderer-translate.component';
export declare const O_TABLE_CELL_RENDERERS: (typeof OTableCellRendererActionComponent | typeof OTableCellRendererBooleanComponent | typeof OTableCellRendererIntegerComponent | typeof OTableCellRendererCurrencyComponent | typeof OTableCellRendererDateComponent | typeof OTableCellRendererImageComponent | typeof OTableCellRendererServiceComponent | typeof OTableCellRendererTimeComponent | typeof OTableCellRendererTranslateComponent)[];
export declare const O_TABLE_CELL_RENDERERS_INPUTS: string[];
export declare const O_TABLE_CELL_RENDERERS_OUTPUTS: string[];
export declare const renderersMapping: {
    action: typeof OTableCellRendererActionComponent;
    boolean: typeof OTableCellRendererBooleanComponent;
    currency: typeof OTableCellRendererCurrencyComponent;
    date: typeof OTableCellRendererDateComponent;
    image: typeof OTableCellRendererImageComponent;
    integer: typeof OTableCellRendererIntegerComponent;
    percentage: typeof OTableCellRendererPercentageComponent;
    real: typeof OTableCellRendererRealComponent;
    service: typeof OTableCellRendererServiceComponent;
    translate: typeof OTableCellRendererTranslateComponent;
    time: typeof OTableCellRendererTimeComponent;
};
//# sourceMappingURL=cell-renderer.d.ts.map