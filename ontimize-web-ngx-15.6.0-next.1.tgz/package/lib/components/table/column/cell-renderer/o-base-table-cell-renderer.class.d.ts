import { AfterContentInit, Injector, OnInit, PipeTransform, TemplateRef } from '@angular/core';
import { OTableColumn } from '../../../../interfaces/o-table-column.interface';
import { Expression } from '../../../../types/expression.type';
import { OTableComponent } from '../../o-table.component';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_BASE_TABLE_CELL_RENDERER: string[];
export declare class OBaseTableCellRenderer implements OnInit, AfterContentInit {
    protected injector: Injector;
    templateref: TemplateRef<any>;
    tableColumn: OTableColumn;
    _filterSource: 'render' | 'data' | 'both';
    filterFunction: (cellValue: any, rowValue: any, quickFilter?: string) => boolean;
    protected type: string;
    protected pipeArguments: any;
    protected componentPipe: PipeTransform;
    constructor(injector: Injector);
    ngOnInit(): void;
    initialize(): void;
    ngAfterContentInit(): void;
    get table(): OTableComponent;
    get column(): string;
    registerRenderer(): void;
    getCellData(cellvalue: any, rowvalue?: any): string;
    getTooltip(cellValue: any, rowValue: any): string;
    set filterSource(val: string);
    get filterSource(): string;
    getFilter(cellValue: any, rowValue?: any): any[];
    getFilterExpression(quickFilter: string): Expression;
    static ɵfac: i0.ɵɵFactoryDeclaration<OBaseTableCellRenderer, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<OBaseTableCellRenderer, never, never, { "filterSource": "filter-source"; "filterFunction": "filter-function"; }, {}, never, never, false, never>;
}
//# sourceMappingURL=o-base-table-cell-renderer.class.d.ts.map