import { Injector, OnDestroy, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { CdkDragDrop } from '@angular/cdk/drag-drop';
import { IExportService } from '../../../../../interfaces/export-service.interface';
import { SnackBarService } from '../../../../../services/snackbar.service';
import { OTranslateService } from '../../../../../services/translate/o-translate.service';
import { OTableExportButtonService } from '../../export-button/o-table-export-button.service';
import { OTableExportConfiguration } from '../../header/table-menu/o-table-export-configuration.class';
import { MatButtonToggleChange } from '@angular/material/button-toggle';
import * as i0 from "@angular/core";
export declare class OTableExportDialogComponent implements OnInit, OnDestroy {
    dialogRef: MatDialogRef<OTableExportDialogComponent>;
    protected injector: Injector;
    config: OTableExportConfiguration;
    protected snackBarService: SnackBarService;
    protected exportService: IExportService;
    protected translateService: OTranslateService;
    protected oTableExportButtonService: OTableExportButtonService;
    protected visibleButtons: string[];
    private subscription;
    private appConfig;
    columns: string[];
    columnsData: string[];
    orientations: {
        text: string;
        value: boolean;
    }[];
    exportTypes: {
        exportType: string;
        svgIcon: string;
        olabel: string;
        className: string;
    }[];
    vertical: boolean;
    selectedExportFormat: string;
    filename: string;
    isExpanded: boolean;
    constructor(dialogRef: MatDialogRef<OTableExportDialogComponent>, injector: Injector, config: OTableExportConfiguration);
    ngOnInit(): void;
    ngOnDestroy(): void;
    initialize(): void;
    configureService(): void;
    updateColumnsSort(): void;
    dropColumns(event: CdkDragDrop<string[]>): void;
    columnsCompareFunction(co1: any, co2: any): boolean;
    export(): void;
    isButtonVisible(btn: string): boolean;
    getDefaultSelection(): string;
    protected handleError(err: any): void;
    onChangeMatButtonToggleGroup(event: MatButtonToggleChange): void;
    getCustomExportButton(type: string): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<OTableExportDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OTableExportDialogComponent, "o-table-export-dialog", never, {}, {}, never, never, false, never>;
}
//# sourceMappingURL=o-table-export-dialog.component.d.ts.map