import { Injector, QueryList } from '@angular/core';
import { AbstractControl } from '@angular/forms';
import { OMatErrorDirective } from '../../../../directives/o-mat-error.directive';
import { OMatErrorOptions } from '../../../../types/o-mat-error.type';
import * as i0 from "@angular/core";
export declare class OTableBaseDialogClass {
    protected injector: Injector;
    protected errorOptions: OMatErrorOptions;
    protected oMatErrorChildren: QueryList<OMatErrorDirective>;
    protected formControl: AbstractControl;
    constructor(injector: Injector);
    protected setFormControl(formControl: AbstractControl): void;
    get tooltipClass(): string;
    get tooltipText(): string;
    protected formControlHasErrors(): boolean;
    hasError(fControl: AbstractControl, error: string): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<OTableBaseDialogClass, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<OTableBaseDialogClass, never, never, {}, {}, never, never, false, never>;
}
//# sourceMappingURL=o-table-base-dialog.class.d.ts.map