import { CdkDragDrop } from '@angular/cdk/drag-drop';
import { ChangeDetectorRef, Injector } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { DialogService } from '../../../../../services/dialog.service';
import { OTranslateService } from '../../../../../services/translate/o-translate.service';
import { OTableBase } from '../../../o-table-base.class';
import * as i0 from "@angular/core";
export type ColumnVisibilityConfiguration = {
    attr: string;
    title: string;
    visible: boolean;
    deleteValueFilter?: boolean;
    deleteSortColummn?: boolean;
    deleteGrupingColumn?: boolean;
};
export declare class OTableVisibleColumnsDialogComponent {
    protected injector: Injector;
    dialogRef: MatDialogRef<OTableVisibleColumnsDialogComponent>;
    columns: ColumnVisibilityConfiguration[];
    rowHeight: string;
    protected dialogService: DialogService;
    protected cd: ChangeDetectorRef;
    protected translateService: OTranslateService;
    protected activeColumnValueFilters: string[];
    protected activeSortColumns: string[];
    protected activeGroupByColumns: string[];
    protected table: OTableBase;
    constructor(injector: Injector, dialogRef: MatDialogRef<OTableVisibleColumnsDialogComponent>, data: any);
    onClickColumn(col: ColumnVisibilityConfiguration): void;
    drop(event: CdkDragDrop<string[]>): void;
    closeDialog(): void;
    private getVisibleColumns;
    private getColumnsOrder;
    private getColumnValueFiltersToRemove;
    private getColumnSortingToRemove;
    private getColumnGroupingToRemove;
    static ɵfac: i0.ɵɵFactoryDeclaration<OTableVisibleColumnsDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OTableVisibleColumnsDialogComponent, "o-table-visible-columns-dialog", never, {}, {}, never, never, false, never>;
}
//# sourceMappingURL=o-table-visible-columns-dialog.component.d.ts.map