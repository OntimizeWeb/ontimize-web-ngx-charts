import { Injector, OnInit } from '@angular/core';
import { OTablePaginator } from '../../../../../interfaces/o-table-paginator.interface';
import { OTableComponent } from '../../../o-table.component';
import { OBaseTablePaginator } from './o-base-table-paginator.class';
import * as i0 from "@angular/core";
export declare const DEFAULT_PAGINATOR_TABLE: string[];
export declare class OTablePaginatorComponent extends OBaseTablePaginator implements OTablePaginator, OnInit {
    protected injector: Injector;
    protected table: OTableComponent;
    showFirstLastButtons: boolean;
    constructor(injector: Injector, table: OTableComponent);
    ngOnInit(): void;
    get pageIndex(): number;
    set pageIndex(value: number);
    isShowingAllRows(selectedLength: number): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<OTablePaginatorComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OTablePaginatorComponent, "o-table-paginator", never, { "pageSize": "page-size"; "pageSizeOptions": "page-size-options"; "showFirstLastButtons": "show-first-last-buttons"; }, {}, never, never, false, never>;
}
//# sourceMappingURL=o-table-paginator.component.d.ts.map