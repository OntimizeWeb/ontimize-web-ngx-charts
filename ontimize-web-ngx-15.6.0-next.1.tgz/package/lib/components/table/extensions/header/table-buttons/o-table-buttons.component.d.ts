import { Injector, OnDestroy, OnInit } from '@angular/core';
import { BehaviorSubject, Subscription } from 'rxjs';
import { OTableButtons } from '../../../../../interfaces/o-table-buttons.interface';
import { OPermissions } from '../../../../../types/o-permissions.type';
import { OTableBase } from '../../../o-table-base.class';
import { OTableButtonComponent } from '../table-button/o-table-button.component';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_TABLE_BUTTONS: string[];
export declare const DEFAULT_OUTPUTS_O_TABLE_BUTTONS: any[];
export declare class OTableButtonsComponent implements OTableButtons, OnInit, OnDestroy {
    protected injector: Injector;
    protected table: OTableBase;
    insertButton: boolean;
    refreshButton: boolean;
    deleteButton: boolean;
    enabledInsertButton: BehaviorSubject<boolean>;
    enabledRefreshButton: BehaviorSubject<boolean>;
    enabledDeleteButton: BehaviorSubject<boolean>;
    protected permissions: OPermissions[];
    protected mutationObservers: MutationObserver[];
    protected subscription: Subscription;
    constructor(injector: Injector, table: OTableBase);
    ngOnInit(): void;
    ngOnDestroy(): void;
    add(): void;
    reloadData(): void;
    remove(): void;
    getPermissionByAttr(attr: string): OPermissions;
    registerButtons(oTableButtons: OTableButtonComponent[]): void;
    get showInsertOButton(): boolean;
    get showRefreshOButton(): boolean;
    get showDeleteOButton(): boolean;
    protected setPermissionsToOTableButton(perm: OPermissions, button: OTableButtonComponent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OTableButtonsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OTableButtonsComponent, "o-table-buttons", never, { "insertButton": "insert-button"; "refreshButton": "refresh-button"; "deleteButton": "delete-button"; }, {}, never, ["*"], false, never>;
}
//# sourceMappingURL=o-table-buttons.component.d.ts.map