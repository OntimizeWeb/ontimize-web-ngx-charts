import { GroupedColumnAggregateConfiguration } from '../../../../../../interfaces/o-table-columns-grouping-interface';
import { AggregateFunction } from '../../../../../../types/aggregate-function.type';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_TABLE_COLUMN_GROUPING_COLUMN: string[];
export declare class OTableColumnsGroupingColumnComponent {
    attr: string;
    title: string;
    aggregateName: string;
    private _aggregate;
    aggregateFunction: AggregateFunction;
    expandGroupsSameLevel: boolean;
    changeAggregateSameLevel: boolean;
    set aggregate(value: string);
    get aggregate(): string;
    getAggregateConfiguration(): GroupedColumnAggregateConfiguration;
    static ɵfac: i0.ɵɵFactoryDeclaration<OTableColumnsGroupingColumnComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OTableColumnsGroupingColumnComponent, "o-table-columns-grouping-column", never, { "attr": "attr"; "title": "title"; "aggregateName": "aggregate-name"; "aggregate": "aggregate"; "aggregateFunction": "aggregate-function"; "expandGroupsSameLevel": "expand-groups-same-level"; "changeAggregateSameLevel": "change-aggregate-same-level"; }, {}, never, never, false, never>;
}
//# sourceMappingURL=o-table-columns-grouping-column.component.d.ts.map