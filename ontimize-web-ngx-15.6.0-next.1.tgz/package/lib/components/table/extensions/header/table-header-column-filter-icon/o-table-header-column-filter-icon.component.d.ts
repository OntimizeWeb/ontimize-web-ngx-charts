import { OnDestroy, OnInit } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { OColumnValueFilter } from '../../../../../types/table/o-column-value-filter.type';
import type { OColumn } from '../../../column';
import { OTableBase } from '../../../o-table-base.class';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_TABLE_COLUMN_FILTER_ICON: string[];
export declare type STATEVIEW = 'HINT' | 'ACTIVE' | 'INACTIVE';
export declare class OTableHeaderColumnFilterIconComponent implements OnInit, OnDestroy {
    table: OTableBase;
    column: OColumn;
    isColumnFilterActive: BehaviorSubject<boolean>;
    filterIconHintVisible: BehaviorSubject<boolean>;
    indicatorNumber: BehaviorSubject<string>;
    private subscription;
    filterIconStateView: BehaviorSubject<STATEVIEW>;
    constructor(table: OTableBase);
    ngOnInit(): void;
    updateStateColumnFilter(): void;
    protected getColumnValueFilterByAttr(): OColumnValueFilter;
    openColumnFilterDialog(event: any): void;
    getFilterIndicatorNumbered(): string;
    setFilterIconHintVisible(visible: boolean): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OTableHeaderColumnFilterIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OTableHeaderColumnFilterIconComponent, "o-table-header-column-filter-icon", never, { "column": "column"; }, {}, never, never, false, never>;
}
//# sourceMappingURL=o-table-header-column-filter-icon.component.d.ts.map