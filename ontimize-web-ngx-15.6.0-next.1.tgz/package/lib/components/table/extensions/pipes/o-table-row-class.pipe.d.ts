import { PipeTransform } from '@angular/core';
import * as i0 from "@angular/core";
export declare class OTableRowClassPipe implements PipeTransform {
    transform(rowData: any, rowIndex: number, rowClassFn?: (row: any, index: number) => string | string[]): string | string[];
    static ɵfac: i0.ɵɵFactoryDeclaration<OTableRowClassPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<OTableRowClassPipe, "oTableRowClass", false>;
}
//# sourceMappingURL=o-table-row-class.pipe.d.ts.map