import { Subject } from 'rxjs';
import { GroupedColumnAggregateConfiguration } from '../../../../interfaces/o-table-columns-grouping-interface';
import { OTableColumnsGroupingColumnComponent } from '../header/table-columns-grouping/columns/o-table-columns-grouping-column.component';
export type AggregateChangeArg = {
    columnAttr: string;
    activeAggregate: string;
    changeAllGroupedRows: boolean;
    row: OTableGroupedRow;
};
export type AggregateColumnData = {
    component: OTableColumnsGroupingColumnComponent;
    activeAggregate: string;
    value: any;
    data: any[];
};
export declare class OTableGroupedRow {
    column: string;
    title: string;
    groupData: any[];
    level: number;
    keysAsString: string;
    parent: OTableGroupedRow;
    expanded: boolean;
    get visible(): boolean;
    private columnsData;
    aggregateFunctionChange: Subject<AggregateChangeArg>;
    constructor(arg?: any);
    hasColumnData(columnAttr: string): boolean;
    hasActiveAggregate(columnAttr: string): boolean;
    getColumnGroupingComponent(columnAttr: string): OTableColumnsGroupingColumnComponent;
    getColumnAggregateValue(columnAttr: string): any;
    setColumnAggregateValue(columnAttr: string, value: any): void;
    expandSameLevel(defaultValue: boolean): boolean;
    setColumnAggregateData(columnAttr: string, value: any[]): void;
    getColumnAggregateData(columnAttr: string): any[];
    setColumnActiveAggregateFunction(columnAttr: string, aggregateFnName: string, emitEvent?: boolean): void;
    getColumnActiveAggregateTitle(columnAttr: string): string;
    initializeColumnAggregate(columnAttr: string, component: OTableColumnsGroupingColumnComponent): void;
    getActiveColumnAggregateConfiguration(columnAttr: string): GroupedColumnAggregateConfiguration;
}
//# sourceMappingURL=o-table-row-group.class.d.ts.map