import { AfterViewInit, ElementRef, Injector, OnInit } from '@angular/core';
import { OSkeletonComponent } from '../../../o-skeleton.component';
import { Observable } from 'rxjs';
import * as i0 from "@angular/core";
export declare class OTableSkeletonComponent extends OSkeletonComponent implements OnInit, AfterViewInit {
    protected elRef: ElementRef;
    protected injector: Injector;
    rows$: Observable<number[]>;
    private readonly cd;
    constructor(elRef: ElementRef, injector: Injector);
    ngOnInit(): void;
    ngAfterViewInit(): void;
    getRows(): number[];
    static ɵfac: i0.ɵɵFactoryDeclaration<OTableSkeletonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OTableSkeletonComponent, "o-table-skeleton", never, {}, {}, never, never, false, never>;
}
//# sourceMappingURL=o-table-skeleton.component.d.ts.map