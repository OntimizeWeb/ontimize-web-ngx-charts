import * as i0 from "@angular/core";
import * as i1 from "./o-mat-sort";
import * as i2 from "./o-mat-sort-header";
import * as i3 from "@angular/common";
export declare class OMatSortModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OMatSortModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OMatSortModule, [typeof i1.OMatSort, typeof i2.OMatSortHeader], [typeof i3.CommonModule], [typeof i1.OMatSort, typeof i2.OMatSortHeader]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OMatSortModule>;
}
//# sourceMappingURL=o-mat-sort-module.d.ts.map