import { ElementRef } from '@angular/core';
import type { OFormLayoutDialogComponent } from '../layouts/form-layout/dialog/o-form-layout-dialog.component';
export interface ILayoutManagerComponent {
    oFormLayoutDialog: OFormLayoutDialogComponent;
    elementRef: ElementRef;
    parentComponent: any;
}
//# sourceMappingURL=layout-manager-component.interface.d.ts.map