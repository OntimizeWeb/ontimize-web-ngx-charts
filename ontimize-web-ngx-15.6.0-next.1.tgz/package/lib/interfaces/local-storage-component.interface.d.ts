export interface ILocalStorageComponent {
    storeState?: boolean;
    getDataToStore(): object;
    getComponentKey(): string;
    getRouteKey?(): string;
}
//# sourceMappingURL=local-storage-component.interface.d.ts.map