import { Injector } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivateChild, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs';
import { OFormLayoutManagerService } from '../../../services/o-form-layout-manager.service';
import { ShareCanActivateChildService } from '../../../services/share-can-activate-child.service';
import * as i0 from "@angular/core";
export declare class CanActivateFormLayoutChildGuard implements CanActivateChild {
    protected injector: Injector;
    protected oFormLayoutService: OFormLayoutManagerService;
    protected shareCanActivateChildService: ShareCanActivateChildService;
    constructor(injector: Injector);
    canActivateChild(childRoute: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean | Observable<boolean> | Promise<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CanActivateFormLayoutChildGuard, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CanActivateFormLayoutChildGuard>;
}
//# sourceMappingURL=o-form-layout-can-activate-child.guard.d.ts.map