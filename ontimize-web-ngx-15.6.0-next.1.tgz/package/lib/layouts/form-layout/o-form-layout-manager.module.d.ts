import * as i0 from "@angular/core";
import * as i1 from "./dialog/o-form-layout-dialog.component";
import * as i2 from "./o-form-layout-manager.component";
import * as i3 from "./tabgroup/o-form-layout-tabgroup.component";
import * as i4 from "./directives/o-form-layout-manager-content.directive";
import * as i5 from "./tabgroup/options/o-form-layout-tabgroup-options.directive";
import * as i6 from "./dialog/options/o-form-layout-dialog-options.directive";
import * as i7 from "./split-pane/o-form-layout-split-pane.component";
import * as i8 from "./split-pane/options/o-form-layout-split-pane-options.directive";
import * as i9 from "@angular/common";
import * as i10 from "../../shared/shared.module";
import * as i11 from "@angular/router";
import * as i12 from "angular-resizable-element";
export declare class OFormLayoutManagerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OFormLayoutManagerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OFormLayoutManagerModule, [typeof i1.OFormLayoutDialogComponent, typeof i2.OFormLayoutManagerComponent, typeof i3.OFormLayoutTabGroupComponent, typeof i4.OFormLayoutManagerContentDirective, typeof i5.OFormLayoutTabGroupOptionsDirective, typeof i6.OFormLayoutDialogOptionsDirective, typeof i7.OFormLayoutSplitPaneComponent, typeof i8.OFormLayoutSplitPaneOptionsDirective], [typeof i9.CommonModule, typeof i10.OSharedModule, typeof i11.RouterModule, typeof i12.ResizableModule], [typeof i2.OFormLayoutManagerComponent, typeof i5.OFormLayoutTabGroupOptionsDirective, typeof i6.OFormLayoutDialogOptionsDirective, typeof i8.OFormLayoutSplitPaneOptionsDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OFormLayoutManagerModule>;
}
//# sourceMappingURL=o-form-layout-manager.module.d.ts.map