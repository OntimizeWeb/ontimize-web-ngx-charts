import { OFormLayoutManagerComponent } from '../../o-form-layout-manager.component';
import * as i0 from "@angular/core";
export declare class OFormLayoutSplitPaneOptionsDirective {
    protected formLayoutManager: OFormLayoutManagerComponent;
    constructor(formLayoutManager: OFormLayoutManagerComponent);
    ngOnChanges(): void;
    mainWidth: number | string;
    mainMaxWidth: number | string;
    mainMinWidth: number | string;
    detailWidth: number | string;
    detailMaxWidth: number | string;
    detailMinWidth: number | string;
    getOptions(): {
        mainWidth: string | number;
        mainMaxWidth: string | number;
        mainMinWidth: string | number;
        detailWidth: string | number;
        detailMaxWidth: string | number;
        detailMinWidth: string | number;
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<OFormLayoutSplitPaneOptionsDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<OFormLayoutSplitPaneOptionsDirective, "o-form-layout-split-pane-options, o-form-layout-manager[mode=\"split-pane\"]", never, { "mainWidth": "main-width"; "mainMaxWidth": "main-max-width"; "mainMinWidth": "main-min-width"; "detailWidth": "detail-width"; "detailMaxWidth": "detail-max-width"; "detailMinWidth": "detail-min-width"; }, {}, never, never, false, never>;
}
//# sourceMappingURL=o-form-layout-split-pane-options.directive.d.ts.map