import { Injector } from '@angular/core';
import { Router } from '@angular/router';
import { Subject } from 'rxjs';
import { AppConfig } from '../config/app-config';
import { MenuCommonItem, MenuGroup, MenuItem, MenuItemRoute } from '../interfaces/app-menu.interface';
import { MenuRootItem } from '../types/menu-root-item.type';
import { PermissionsService } from './permissions/permissions.service';
import * as i0 from "@angular/core";
export declare class AppMenuService {
    protected injector: Injector;
    protected router: Router;
    protected _config: AppConfig;
    protected MENU_ROOTS: MenuRootItem[];
    protected ALL_MENU_ITEMS: MenuRootItem[];
    protected activeItem: MenuItemRoute;
    protected permissionsService: PermissionsService;
    onClick: Subject<void>;
    onPermissionMenuChanged: Subject<void>;
    constructor(injector: Injector);
    setMenuItemsByMenuConfiguration(): void;
    mergeMenuItemsWithPermissions(): void;
    getMenuRoots(): MenuRootItem[];
    getMenuRootById(id: string): MenuRootItem;
    getAllMenuItems(): MenuRootItem[];
    getMenuItemById(id: string): MenuItem | MenuGroup;
    getMenuItemType(item: MenuRootItem): string;
    isMenuGroup(item: MenuRootItem): boolean;
    isMenuGroupRoute(item: MenuRootItem): boolean;
    isItemActive(item: MenuItemRoute): boolean;
    isRouteItem(item: MenuItemRoute): boolean;
    isVisible(item: MenuCommonItem): boolean;
    private getMenuItems;
    private setActiveItem;
    static ɵfac: i0.ɵɵFactoryDeclaration<AppMenuService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AppMenuService>;
}
//# sourceMappingURL=app-menu.service.d.ts.map