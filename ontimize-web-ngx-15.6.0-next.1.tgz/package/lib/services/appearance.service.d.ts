import { Injector } from '@angular/core';
import { Observable } from 'rxjs';
import { AppConfig } from '../config/app-config';
import { LocalStorageService } from './local-storage.service';
import * as i0 from "@angular/core";
export declare class AppearanceService {
    protected injector: Injector;
    readonly darkThemeClass = "o-dark";
    private isDarkModeSubject;
    isDarkMode$: Observable<boolean>;
    protected _appConfig: AppConfig;
    protected _document: Document;
    protected localStorageService: LocalStorageService;
    constructor(injector: Injector);
    setDarkMode(isDarkMode: boolean): void;
    isDarkMode(): boolean;
    updateThemeClass(isDark?: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AppearanceService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AppearanceService>;
}
//# sourceMappingURL=appearance.service.d.ts.map