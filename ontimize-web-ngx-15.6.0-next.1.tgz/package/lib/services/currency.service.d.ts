import { Injector } from '@angular/core';
import { NumberService } from './number.service';
import * as i0 from "@angular/core";
export declare class CurrencyService {
    protected injector: Injector;
    static DEFAULT_CURRENCY_SYMBOL: string;
    static DEFAULT_CURRENCY_SYMBOL_POSITION: string;
    protected _numberService: NumberService;
    protected _symbol: string;
    protected _symbolPosition: string;
    constructor(injector: Injector);
    get symbol(): string;
    set symbol(value: string);
    get symbolPosition(): string;
    set symbolPosition(value: string);
    getCurrencyValue(value: any, args: any): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<CurrencyService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CurrencyService>;
}
//# sourceMappingURL=currency.service.d.ts.map