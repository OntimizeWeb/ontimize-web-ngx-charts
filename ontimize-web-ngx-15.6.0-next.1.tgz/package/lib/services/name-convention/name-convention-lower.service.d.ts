import { BaseNameConvention } from './base-name-convention.service';
export declare class NameConventionLower extends BaseNameConvention {
    parseToStringCase(value: any): any;
    parseOppositeToStringCase(value: any): any;
}
//# sourceMappingURL=name-convention-lower.service.d.ts.map