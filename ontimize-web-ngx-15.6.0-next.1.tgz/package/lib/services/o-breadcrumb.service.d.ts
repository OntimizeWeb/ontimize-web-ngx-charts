import { Injector } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { OBreadcrumb } from '../types/o-breadcrumb-item.type';
import * as i0 from "@angular/core";
export declare class OBreadcrumbService {
    protected injector: Injector;
    breadcrumbs$: BehaviorSubject<OBreadcrumb[]>;
    constructor(injector: Injector);
    static ɵfac: i0.ɵɵFactoryDeclaration<OBreadcrumbService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OBreadcrumbService>;
}
//# sourceMappingURL=o-breadcrumb.service.d.ts.map