import { Injector } from '@angular/core';
import type { OFormLayoutManagerComponent } from '../layouts/form-layout/o-form-layout-manager.component';
import { OFormLayoutManagerContext } from '../types/form-layout-manager-context.type';
import * as i0 from "@angular/core";
export declare class OFormLayoutManagerService {
    protected injector: Injector;
    protected registeredFormLayoutManagers: {};
    protected _activeFormLayoutManager: OFormLayoutManagerComponent;
    private _context;
    constructor(injector: Injector);
    registerFormLayoutManager(comp: OFormLayoutManagerComponent): void;
    removeFormLayoutManager(comp: OFormLayoutManagerComponent): void;
    get activeFormLayoutManager(): OFormLayoutManagerComponent;
    set activeFormLayoutManager(arg: OFormLayoutManagerComponent);
    set context(value: OFormLayoutManagerContext);
    get context(): OFormLayoutManagerContext;
    static ɵfac: i0.ɵɵFactoryDeclaration<OFormLayoutManagerService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OFormLayoutManagerService>;
}
//# sourceMappingURL=o-form-layout-manager.service.d.ts.map