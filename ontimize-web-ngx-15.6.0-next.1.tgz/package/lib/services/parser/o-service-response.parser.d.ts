import { HttpErrorResponse } from '@angular/common/http';
import { Injector } from '@angular/core';
import { Subscriber } from 'rxjs';
import { AppConfig } from '../../config/app-config';
import { ServiceResponse } from '../../interfaces/service-response.interface';
import { BaseService } from '../base-service.class';
import { NameConvention } from '../name-convention/name-convention.service';
import * as i0 from "@angular/core";
export declare class OntimizeServiceResponseParser<T extends ServiceResponse> {
    protected injector: Injector;
    appConfig: AppConfig;
    nameConvention: NameConvention;
    constructor(injector: Injector);
    parseSuccessfulResponse(resp: T, subscriber: Subscriber<T>, service: BaseService<T>): void;
    parseData(data: any): any;
    parseUnsuccessfulResponse(error: HttpErrorResponse, subscriber: Subscriber<T>, service: BaseService<T>): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OntimizeServiceResponseParser<any>, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OntimizeServiceResponseParser<any>>;
}
//# sourceMappingURL=o-service-response.parser.d.ts.map