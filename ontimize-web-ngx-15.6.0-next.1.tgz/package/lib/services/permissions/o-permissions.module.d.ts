import { Injector } from '@angular/core';
import { PermissionsService } from './permissions.service';
import * as i0 from "@angular/core";
import * as i1 from "@angular/common";
export declare function getPermissionsServiceProvider(injector: Injector): PermissionsService;
export declare class OPermissionsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OPermissionsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OPermissionsModule, never, [typeof i1.CommonModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OPermissionsModule>;
}
//# sourceMappingURL=o-permissions.module.d.ts.map