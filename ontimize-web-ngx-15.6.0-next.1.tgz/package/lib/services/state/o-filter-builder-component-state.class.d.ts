import { OFilterBuilderStatus, OFilterBuilderValues } from '../../types/o-filter-builder-values.type';
import { DefaultComponentStateClass } from './o-component-state.class';
export declare class OFilterBuilderComponentStateClass extends DefaultComponentStateClass {
    filterBuilderValues: OFilterBuilderValues[];
    get storedFilterBuilders(): OFilterBuilderStatus[];
    set storedFilterBuilders(value: OFilterBuilderStatus[]);
    addStoredFilter(filter: OFilterBuilderStatus): void;
    deleteStoredFilter(filterName: string): void;
    applyFilter(filterName: string): void;
    getStoredFilter(filterName: string): OFilterBuilderValues[];
}
//# sourceMappingURL=o-filter-builder-component-state.class.d.ts.map