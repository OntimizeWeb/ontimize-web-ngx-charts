import { DefaultServiceComponentStateClass } from './o-component-state.class';
export declare class OGridComponentStateClass extends DefaultServiceComponentStateClass {
    protected 'sort-column': string;
    currentPage: number;
    'quickFilterActiveColumns': string;
    get sortColumn(): string;
    set sortColumn(value: string);
}
//# sourceMappingURL=o-grid-component-state.class.d.ts.map