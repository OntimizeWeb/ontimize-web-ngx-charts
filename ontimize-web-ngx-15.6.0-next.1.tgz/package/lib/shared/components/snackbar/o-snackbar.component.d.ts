import { Injector } from '@angular/core';
import { MatSnackBarRef } from '@angular/material/snack-bar';
import * as i0 from "@angular/core";
export declare type OSnackBarIconPosition = 'left' | 'right';
export declare class OSnackBarConfig {
    action?: string;
    milliseconds?: number;
    icon?: string;
    iconPosition?: OSnackBarIconPosition;
    cssClass?: string;
}
export declare class OSnackBarComponent {
    protected injector: Injector;
    message: string;
    action: string;
    icon: string;
    iconPosition: OSnackBarIconPosition;
    protected snackBarRef: MatSnackBarRef<{}>;
    constructor(injector: Injector);
    open(message: string, config?: OSnackBarConfig): void;
    onAction(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OSnackBarComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OSnackBarComponent, "o-snackbar", never, {}, {}, never, never, false, never>;
}
//# sourceMappingURL=o-snackbar.component.d.ts.map