import { MatDateFormats } from '@angular/material/core';
export declare class OntimizeMatDateFormats {
    protected DEFAULT_DATE_FORMATS: MatDateFormats;
    factory(): any;
}
export declare function dateFormatFactory(): any;
//# sourceMappingURL=mat-date-formats.factory.d.ts.map