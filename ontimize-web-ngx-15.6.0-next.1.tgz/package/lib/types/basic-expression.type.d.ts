import { Expression } from './expression.type';
export type BasicExpression = {
    '@basic_expression': Expression;
};
//# sourceMappingURL=basic-expression.type.d.ts.map