import { Injector } from "@angular/core";
export type OConfigureMessageServiceArgs = {
    injector: Injector;
    baseService: any;
    serviceType: string;
};
//# sourceMappingURL=configure-message-service-args.type.d.ts.map