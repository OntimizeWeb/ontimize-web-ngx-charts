export type OExportConfiguration = {
    path: string;
};
//# sourceMappingURL=export-configuration.type.d.ts.map