export type OFormLayoutManagerContext = {
    label: string;
};
//# sourceMappingURL=form-layout-manager-context.type.d.ts.map