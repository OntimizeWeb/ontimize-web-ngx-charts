export * from './o-form-global-config.type';
//# sourceMappingURL=index.d.ts.map