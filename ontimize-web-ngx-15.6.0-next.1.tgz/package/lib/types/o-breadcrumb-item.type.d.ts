export type OBreadcrumb = {
    label: string;
    displayText?: string;
    route: string;
    queryParams?: object;
};
//# sourceMappingURL=o-breadcrumb-item.type.d.ts.map