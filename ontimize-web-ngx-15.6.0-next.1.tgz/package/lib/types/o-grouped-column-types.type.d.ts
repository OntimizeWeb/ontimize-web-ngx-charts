export type OGroupedColumnTypes = {
    attr: string;
    type: string;
};
//# sourceMappingURL=o-grouped-column-types.type.d.ts.map