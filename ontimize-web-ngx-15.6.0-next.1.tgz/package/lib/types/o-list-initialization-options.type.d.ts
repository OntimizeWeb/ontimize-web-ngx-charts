export type OListInitializationOptions = {
    entity?: string;
    service?: string;
    columns?: string;
    quickFilterColumns?: string;
    keys?: string;
    parentKeys?: string;
};
//# sourceMappingURL=o-list-initialization-options.type.d.ts.map